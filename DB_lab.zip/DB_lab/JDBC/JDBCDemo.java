import java.sql.*;

// Compile: javac -cp ".:C:\Desktop Data\Education\Academics\TY\SEM-V\DBMS_Lab\JDBC\JDBC\mysql-connector-j-9.1.0.jar" JDBCDemo.java
// Run: java -cp ".;C:\Desktop Data\Education\Academics\TY\SEM-V\DBMS_Lab\JDBC\JDBC\mysql-connector-j-9.1.0.jar" JDBCDemo
  

public class JDBCDemo {
    public static void main(String[] args) {
        // Database connection details
        String url = "jdbc:mysql://localhost:3306/db_lab";
        String user = "root";
        String password = "it1234";

        // JDBC objects
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            // Load MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish connection to the database
            connection = DriverManager.getConnection(url, user, password);
            System.out.println("Connected to the database!");

            // Create a statement
            statement = connection.createStatement();

            // Execute SELECT query on the `student` table
            String query = "SELECT * FROM student";
            resultSet = statement.executeQuery(query);

            // Process the result set
            System.out.println("ID | Name      | Age");
            System.out.println("--------------------");
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("sname");
                int age = resultSet.getInt("age");
                System.out.printf("%2d | %-9s | %d%n", id, name, age);
            }

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            // Close resources
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
